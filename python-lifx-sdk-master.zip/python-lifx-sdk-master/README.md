# python-lifx-sdk
An SDK for local LAN control of bulbs, using Python

The script has only been designed to work on Python 2.

